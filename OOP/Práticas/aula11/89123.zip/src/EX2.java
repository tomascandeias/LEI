import java.io.*;
import java.util.*;

public class EX2 {
	public static void main(String[] args) throws IOException {
		Map<String, String> companhias = new TreeMap<>();
		List<Voo> lstVoos = new LinkedList<>();

		Scanner scv = null, scc = null;

		try{
			scv = new Scanner(new File("src/voos.txt"));
			scc = new Scanner(new File("src/companhias.txt"));
		}catch (FileNotFoundException e){
			System.out.println("O ficheiro não foi encontrado!");
		}

		scc.nextLine();
		while (scc.hasNextLine()){
			String[] line = scc.nextLine().split("[\t]");
			companhias.put(line[0], line[1]);
		}
		scc.close();

		scv.nextLine();
		while (scv.hasNextLine()){
			String[] line = scv.nextLine().split("[\t]");
			if (line.length == 4){
				lstVoos.add(new Voo(line[0], line[1], line[2], line[3]));
			}else{
				lstVoos.add(new Voo(line[0], line[1], line[2]));
			}
		}
		scv.close();

		publicTable(companhias, lstVoos);

	}

	private static void publicTable(Map<String, String> companhias, List<Voo> lstVoos) throws IOException {
		PrintWriter info = new PrintWriter(new FileWriter("src/Infopublico.txt", true));

		System.out.printf("%-10s%-10s%-30s%-30s%-10s%s\n", "Hora", "Voo", "Companhia", "Origem", "Atraso", "Obs");
		for (Voo v : lstVoos){
			String sf = String.format("%-10s%-10s%-30s%-30s%-10s%s", v.getHora(), v.getCodigo(), companhias.get(v.getCompanhia()),
					v.getOrigem(), v.getAtraso(), ((!v.getPrevisto().equals("")) ? "Previsto: "+v.getPrevisto() : v.getPrevisto()));

			System.out.println(sf);
			info.append(sf + "\n");
		}

	}
}
