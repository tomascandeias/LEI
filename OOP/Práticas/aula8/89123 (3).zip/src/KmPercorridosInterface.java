public interface KmPercorridosInterface {
	void trajeto(int km);
	int ultimoTrajeto();
	int distanciaTotal();
}
