public class Legume extends Vegetariano{
	public Legume(String nome, double proteinas, double calorias, double peso) {
		super(nome, proteinas, calorias, peso);
	}
}
