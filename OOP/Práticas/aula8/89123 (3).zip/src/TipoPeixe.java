public enum TipoPeixe {
	CONGELADO, FRESCO;
}
