public class Cereal extends Vegetariano{
	public Cereal(String nome, double proteinas, double calorias, double peso) {
		super(nome, proteinas, calorias, peso);
	}
}
