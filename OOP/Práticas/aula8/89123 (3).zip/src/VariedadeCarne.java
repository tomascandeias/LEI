public enum VariedadeCarne {
	VACA, FRANGO, PORCO, PERU, OUTRO;
}
