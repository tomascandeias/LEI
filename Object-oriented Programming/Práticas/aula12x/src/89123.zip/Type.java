public enum Type {
	comedy, suspense, action, horror, drama;
}
